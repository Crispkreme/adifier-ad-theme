<?php
if( !class_exists('Adifier_Elementor_kc_categories_tree') ){
class Adifier_Elementor_kc_categories_tree extends Adifier_Elementor_Base {

}
}
?>