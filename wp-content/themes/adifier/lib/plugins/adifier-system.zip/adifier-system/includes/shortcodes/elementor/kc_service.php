<?php
if( !class_exists('Adifier_Elementor_kc_service') ){
class Adifier_Elementor_kc_service extends Adifier_Elementor_Base {

}
}
?>